import './bootstrap';
import "flyonui/flyonui"
import $ from 'jquery';
window.$ = $;
import Swal from "sweetalert2";
window.Swal = Swal;
