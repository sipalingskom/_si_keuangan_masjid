<main>

    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('landing-page.header');

$__html = app('livewire')->mount($__name, $__params, 'lw-2300648460-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    

    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('landing-page.infaq');

$__html = app('livewire')->mount($__name, $__params, 'lw-2300648460-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    

    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('landing-page.zakat');

$__html = app('livewire')->mount($__name, $__params, 'lw-2300648460-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    

    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('agenda-full-calender');

$__html = app('livewire')->mount($__name, $__params, 'lw-2300648460-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    

    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('landing-page.rekening-masjid');

$__html = app('livewire')->mount($__name, $__params, 'lw-2300648460-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    

    
    <section id="kontak" class="w-auto px-5 xl:px-0">
        <div class="container py-24 mx-auto">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('landing-page.cari-kode');

$__html = app('livewire')->mount($__name, $__params, 'lw-2300648460-5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <div class="w-auto text-white card bg-gradient-to-r from-primary to-[#7EEDF4]">
                <div class="flex justify-between py-6">
                    <div>
                        <div class="flex flex-wrap justify-center card-body">
                            <h5 class="uppercase font-medium text-xs lg:text-sm mb-1.5">Whatsapp (WA)</h5>
                            <p class="text-sm font-bold md:text-base lg:text-2xl"><?php echo e($setting ? $setting->no_telp :
                                "no_telp"); ?>

                            </p>
                        </div>
                        <div class="flex flex-wrap justify-center card-body">
                            <h5 class="uppercase font-medium text-xs lg:text-sm mb-1.5">Email</h5>
                            <p class="text-sm font-bold md:text-base lg:text-2xl"><?php echo e($setting ? ucwords($setting->email)
                                : "email"); ?></p>
                        </div>
                    </div>
                    <img src="<?php echo e(asset('img/undraw_contact_us_re_4qqt.svg')); ?>" alt=""
                        class="hidden px-6 w-96 md:inline" />
                </div>
            </div>
        </div>
    </section>
    

    
    <footer class="px-6 pt-6 pb-4 text-center bg-gray-900">
        <h2 class="mb-3 text-2xl no-underline fi-logo text-primary">
            <?php echo e($setting ? ucwords($setting->nama_web) : "nama_web"); ?>

        </h2>
        <p class="w-full mx-auto mb-8 text-sm text-gray-100 md:w-1/2 lg:w-1/3">
            <?php echo e($setting ? ucwords($setting->alamat) : "alamat"); ?>

        </p>
        <small class="text-gray-100"><span class="font-semibold">Copyright © <?php echo e(date('Y')); ?></span> - <span
                class="text-xs font-extralight fi-logo">Sistem Informasi Keuangan Masjid.</span></small>
    </footer>
    

    
    <section id="backtotop" class="hidden">
        <a href="#home" class="bg-white shadow rounded p-1.5 bottom-6 right-6 fixed backtotop cursor-pointer">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="#13ADB7"
                class="size-5">
                <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 18.75 7.5-7.5 7.5 7.5" />
                <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 7.5-7.5 7.5 7.5" />
            </svg>
        </a>
    </section>
    
</main>
<?php /**PATH C:\Sapta\Filament Apps\Skripsi\_si_keuangan_masjid\resources\views/livewire/landing-page.blade.php ENDPATH**/ ?>