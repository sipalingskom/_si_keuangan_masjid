<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">

    <meta name="application-name" content="<?php echo e(config('app.name')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="shortcut icon" href="<?php echo e(asset('favicon.png')); ?>" type="image/x-icon">
    <title><?php echo e($title ?? config('app.name')); ?></title>

    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>

    <?php echo \Filament\Support\Facades\FilamentAsset::renderStyles() ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <style>
        .swal2-confirm.swal2-styled {
            background-color: #13ADB7 !important;
            border: #13ADB7 !important;
        }

        .fc-h-event {
            background-color: #13ADB7 !important;
            border: #13ADB7 !important;
        }

        .fc-toolbar-chunk .fc-toolbar-title#fc-dom-1 {
            font-weight: 700 !important;
            color: #13adb7 !important;
            font-size: 22px !important;
        }

        .fc-toolbar-chunk .fc-today-button,
        .fc-toolbar-chunk .fc-next-button,
        .fc-toolbar-chunk .fc-prev-button {
            background-color: #13ADB7;
            border: #13ADB7;
        }

        .fc-toolbar-chunk .fc-today-button:hover {
            background-color: #068993;
            border: #068993;
        }

        .fc-toolbar-chunk .fc-today-button:disabled {
            background-color: #39b4bc;
            border: #39b4bc;
        }

        @media only screen and (max-width: 425px) {
            .fc-header-toolbar.fc-toolbar {
                display: flex;
                flex-direction: column;
            }
        }
    </style>
</head>

<body class="antialiased bg-body">

    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('navbar');

$__html = app('livewire')->mount($__name, $__params, 'lw-1684695932-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php echo e($slot); ?>


    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('notifications');

$__html = app('livewire')->mount($__name, $__params, 'lw-1684695932-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>


    <?php echo \Filament\Support\Facades\FilamentAsset::renderScripts() ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>

    <script type="module">
        $(window).on('hashchange', function(e){
            history.replaceState ("", document.title, e.originalEvent.oldURL);
        });

        $(window).scroll(function(){
            if ($(this).scrollTop()) {
                $('#backtotop').removeClass('hidden');
                $('#navbar').addClass('bg-white');
                $('#navbar').addClass('shadow-sm');
                $('#navbar').addClass('py-3');
                $('#nav-list').removeClass('text-white');
            } else {
                $('#backtotop').addClass('hidden');
                $('#navbar').removeClass('bg-white');
                $('#navbar').removeClass('shadow-sm');
                $('#navbar').removeClass('py-3');
                $('#nav-list').addClass('text-white');
            }
        });
    </script>

    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\Rino\Filament Apps\Skripsi\_si_keuangan_masjid\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>