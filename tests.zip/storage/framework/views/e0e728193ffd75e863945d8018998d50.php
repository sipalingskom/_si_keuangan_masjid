<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH C:\Rino\Filament Apps\Skripsi\_si_keuangan_masjid\resources\views/livewire/list-infaq.blade.php ENDPATH**/ ?>