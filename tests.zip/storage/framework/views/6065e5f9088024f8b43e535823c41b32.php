<div>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split(\App\Filament\Resources\AgendaResource\Widgets\FullCalenderAgenda::class);

$__html = app('livewire')->mount($__name, $__params, 'lw-3918561557-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
</div><?php /**PATH C:\Rino\Filament Apps\Skripsi\_si_keuangan_masjid\resources\views/livewire/agenda-full-calender.blade.php ENDPATH**/ ?>