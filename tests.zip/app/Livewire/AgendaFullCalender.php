<?php

namespace App\Livewire;

use Livewire\Component;

class AgendaFullCalender extends Component
{
    public function render()
    {
        return view('livewire.agenda-full-calender');
    }
}
