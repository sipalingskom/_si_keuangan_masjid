<div>
    @livewire(\App\Filament\Resources\AgendaResource\Widgets\FullCalenderAgenda::class)
</div>