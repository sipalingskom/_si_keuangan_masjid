import './bootstrap';
import "flyonui/flyonui"
import $ from 'jquery';
window.$ = $;

